# Data Warehouse Project

[DW Epics](DW%20Epics%201df99f7061c78060b4bdcf18be4fd7a4.csv)

[DW Tasks](DW%20Tasks%201df99f7061c7801f99d1f14ac4a83378.csv)